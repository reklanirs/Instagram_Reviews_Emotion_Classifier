#!/usr/local/bin/python3
# -*- coding: utf-8 -*- 
import os,re,sys,time
import subprocess,shlex
import math,random
import json
from pathlib import Path

clear = lambda: os.system('cls' if os.name=='nt' else 'clear')
#sys.stdin=open('in.txt','r')

current_path = os.getcwd()
target_path = os.path.expanduser('~/Workspace/Instagram/airpods_case_1')


def get_comments(target_path='.'):
    ret = []
    comment_files = sorted(Path(target_path).glob('*comments.json'))
    for file in comment_files:
        with open(file, 'r') as f:
            j = json.load(f)
        for i in j:
            ret.append(i['text'])
    print(f'Totally {len(ret)} comments.')
    return ret


def save_to_file(sl, fname='tmp.txt'):
    with open(fname, 'w') as fout:
        for i in sl:
            fout.write(i.strip()+'\n')
    return


def get_100(f=target_path+'.txt'):
    with open(f, 'r') as fin:
        s = fin.readlines()
    s = sorted(s, key=lambda x: len(x), reverse=True)
    print(s[0])
    save_to_file(s[:100], fname='airpods_case_1_100.txt')
    pass

def main():
    r = get_comments(target_path)
    for i in range(5):
        print(r[i])
    save_to_file(r, fname = Path(target_path).name+'.txt')
    pass

if __name__ == '__main__':
    main()
    